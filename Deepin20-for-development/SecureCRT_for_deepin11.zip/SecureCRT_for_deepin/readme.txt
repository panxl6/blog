1、安装SecureCRT
sudo dpkg -i scrt-8.3.1-1537.ubuntu16-64.x86_64.deb

2、运行破解脚本，提示破解信息License
sudo perl securecrt_linux_crack.pl /usr/bin/SecureCRT

提示如下：
crack successful

License:

	Name:		xiaobo_l
	Company:	www.boll.me
	Serial Number:	03-94-294583
	License Key:	ABJ11G 85V1F9 NENFBK RBWB5W ABH23Q 8XBZAC 324TJJ KXRE5D
	Issue Date:	04-20-2017

3、运行SecureCRT填写注册信息
(注意填License Key时需要将中间的空格去掉，否则可能报版本号不识别)


安装SecureCRT提示缺少依赖文件libssl1.0.0的解决方法：
因为新版本的系统中都是高版本，而libssl1.0.0在新的更新源里没有了，可以直接去
https://pkgs.org/download/libssl1.0.0下载对应的版本
sudo dpkg -i libssl1.0.0_1.0.1t-1+deb8u8_amd64.deb 

当运行SecureCRT时报错提示缺少libpng12.so.0解决办法：
1、下载libpng12-0_1.2.54-1ubuntu1_amd64.deb进行安装
或
2、直接将libpng12.so.0拷贝到/usr/lib/x86_64-linux-gnu/目录下 
sudo cp libpng12.so.0 /usr/lib/x86_64-linux-gnu/






Name:meisi

Company:TEAM ZWT

Serial Number:03-14-367662

License Key:ACCFAX R9FHJ7 QZVS2P JPBCVA ABCMBF HNEJ2T R9EVZN 2EEK2Q

Issue Date:01-30-2018

Features:

 

Name:Ronaldo

Company:TEAM ZWT

Serial Number:03-49-375243

License Key:ACGRNV 7BS22M RHCXRZ Q1ZTU6 AAUAUZ NGR1BA BQYM94 2JVHP4

Issue Date:01-30-2018

Features:

